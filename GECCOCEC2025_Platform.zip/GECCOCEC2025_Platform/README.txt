%%This years' competition considers the number of function evaluations. As such, the lower the value the better

In the main.m file please find the parameter to modify:
 -No_evals = 5000

This parameter is fixed over the number of trials. Changing this parameter for the different trials is not allowed.


%%Enjoy this years' competition!
